<?php

use Illuminate\Foundation\Inspiring;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Schedule;

Artisan::command('inspire', function () {
    $this->comment(Inspiring::quote());
})->purpose('Display an inspiring quote');

Schedule::command('notifications:abandoned-carts --hours=2')
    ->everyThirtyMinutes()
    ->withoutOverlapping();

Schedule::command('sync:cleanup --days=7')
    ->dailyAt('04:00')
    ->withoutOverlapping();
