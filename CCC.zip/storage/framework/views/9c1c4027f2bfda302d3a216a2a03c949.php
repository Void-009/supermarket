<div x-data="productQuickView()" x-show="open" x-cloak
    style="display:none; position:fixed; inset:0; z-index:2147483647;">

    
    <div x-show="open" @click="closeModal()"
        style="position:absolute; inset:0; background:rgba(0,0,0,0.5); backdrop-filter:blur(4px);"
        x-transition:enter="transition ease-out duration-200"
        x-transition:enter-start="opacity-0" x-transition:enter-end="opacity-100"
        x-transition:leave="transition ease-in duration-150"
        x-transition:leave-start="opacity-100" x-transition:leave-end="opacity-0"></div>

    
    <div x-show="open"
        x-transition:enter="transition ease-out duration-200"
        x-transition:enter-start="opacity-0 scale-95" x-transition:enter-end="opacity-100 scale-100"
        x-transition:leave="transition ease-in duration-150"
        x-transition:leave-start="opacity-100 scale-100" x-transition:leave-end="opacity-0 scale-95"
        class="w-[calc(100vw-2rem)] max-w-lg mx-auto"
        style="position:absolute; top:50%; left:50%; transform:translate(-50%,-50%); max-height:90dvh; overflow-y:auto; background:white; border-radius:1rem; box-shadow:0 25px 50px -12px rgba(0,0,0,0.25); z-index:2147483647; padding-top:env(safe-area-inset-top,0px); padding-bottom:env(safe-area-inset-bottom,0px);"
        @click.outside="closeModal()">

        
        <button @click="closeModal()" type="button"
            class="absolute top-3 right-3 z-50 w-8 h-8 flex items-center justify-center rounded-full border-none cursor-pointer"
            style="background:rgba(255,255,255,0.8); box-shadow:0 1px 3px rgba(0,0,0,0.1);">
            <svg xmlns="http://www.w3.org/2000/svg" class="w-4 h-4 text-gray-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"/></svg>
        </button>

        <template x-if="product">
            <div>
                
                <div class="w-full flex items-center justify-center"
                    style="background:#f9fafb; max-height:55vh; border-radius:1rem 1rem 0 0;">
                    <template x-if="product.image_url">
                        <img :src="'/storage/' + product.image_url" :alt="product.display_name || product.name" style="max-width:100%; max-height:55vh; width:auto; height:auto; object-fit:contain; display:block;">
                    </template>
                    <template x-if="!product.image_url">
                        <div style="width:100%; height:100%; display:flex; align-items:center; justify-content:center; background:linear-gradient(135deg, #ecfdf5, #d1fae5);">
                            <span style="font-size:3rem;">&#x1F6D2;</span>
                        </div>
                    </template>
                </div>

                
                <div class="p-4 sm:p-6">
                    <template x-if="product.category">
                        <span style="font-size:12px; font-weight:600; color:#059669; text-transform:uppercase; letter-spacing:0.05em;" x-text="product.category"></span>
                    </template>

                    <h3 style="font-size:18px; font-weight:700; color:#111827; margin-top:4px; line-height:1.3; font-family:'Poppins',sans-serif; overflow-wrap:break-word;" x-text="picker.selected ? (picker.selected.display_name || picker.selected.name) : (product.display_name || product.name)"></h3>

                    
                    <div style="margin-top:12px; display:flex; align-items:baseline; gap:8px;">
                        <template x-if="picker.selected">
                            <span style="font-size:24px; font-weight:800; color:#059669;" x-text="picker.fmt(picker.price)"></span>
                        </template>
                        <template x-if="picker.compareAt && picker.selected">
                            <span style="font-size:14px; color:#9ca3af; text-decoration:line-through;" x-text="picker.fmt(picker.compareAt)"></span>
                        </template>
                    </div>

                    
                    <template x-if="picker.options.length > 1">
                        <div style="margin-top:16px;">
                            <span style="font-size:12px; font-weight:600; color:#4b5563; text-transform:uppercase; letter-spacing:0.05em;"><?php echo e(__('messages.variations')); ?></span>
                            <div style="margin-top:8px; display:flex; flex-direction:column; gap:8px;">
                                <template x-for="o in picker.options" :key="o.id">
                                    <button @click="picker.select(o.id)" type="button"
                                        :class="picker.selectedId === o.id ? 'ring-2 ring-emerald-500 border-emerald-500 bg-emerald-50' : 'hover:border-gray-300'"
                                        style="display:flex; align-items:center; justify-content:space-between; gap:8px; width:100%; padding:10px 12px; border:1px solid #e5e7eb; border-radius:10px; background:white; cursor:pointer; text-align:left;">
                                        <span style="font-size:13px; font-weight:600; color:#111827; flex:1; min-width:0;" x-text="o.display_name || o.name"></span>
                                        <span style="display:flex; align-items:center; gap:10px; shrink:0;">
                                            <template x-if="o.stock < 1">
                                                <span style="font-size:11px; font-weight:600; color:#b91c1c;"><?php echo e(__('messages.out_of_stock')); ?></span>
                                            </template>
                                            <span style="font-size:13px; font-weight:700; color:#059669;" x-text="picker.fmt(o.selling_price)"></span>
                                        </span>
                                    </button>
                                </template>
                            </div>
                        </div>
                    </template>

                    
                    <div style="margin-top:16px;">
                        <template x-if="picker.selected && picker.selected.stock > 0">
                            <span style="display:inline-flex; align-items:center; gap:6px; padding:6px 10px; background:#ecfdf5; color:#15803d; border-radius:8px; font-size:12px; font-weight:600; border:1px solid #bbf7d0;">
                                In Stock
                                <template x-if="!picker.selected.is_variation">
                                    <span style="color:#16a34a; font-weight:400;" x-text="'(' + picker.selected.stock + ' <?php echo e(__("messages.available", ["count" => ""])); ?>)'"></span>
                                </template>
                            </span>
                        </template>
                        <template x-if="!picker.selected || picker.selected.stock < 1">
                            <span style="display:inline-flex; align-items:center; gap:6px; padding:6px 10px; background:#fef2f2; color:#b91c1c; border-radius:8px; font-size:12px; font-weight:600; border:1px solid #fecaca;">
                                <?php echo e(__('messages.out_of_stock')); ?>

                            </span>
                        </template>
                    </div>

                    
                    <template x-if="picker.selected && picker.selected.stock > 0">
                        <div style="margin-top:20px;">
                            <div class="flex flex-col gap-3 sm:flex-row sm:items-center sm:gap-3">
                                <div style="display:flex; align-items:center; border:1px solid #e5e7eb; border-radius:12px; overflow:hidden;">
                                    <button @click="picker.qty = Math.max(1, picker.qty - 1)" type="button" style="width:40px; height:40px; display:flex; align-items:center; justify-content:center; color:#4b5563; cursor:pointer; border:none; background:transparent;">
                                        <svg xmlns="http://www.w3.org/2000/svg" style="width:16px; height:16px;" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M20 12H4"/></svg>
                                    </button>
                                    <input type="number" x-model.number="picker.qty" min="1" :max="picker.maxStock || 99999" style="width:48px; height:40px; text-align:center; border-left:1px solid #e5e7eb; border-right:1px solid #e5e7eb; font-size:14px; font-weight:600; outline:none;">
                                    <button @click="picker.incQty()" type="button" style="width:40px; height:40px; display:flex; align-items:center; justify-content:center; color:#4b5563; cursor:pointer; border:none; background:transparent;">
                                        <svg xmlns="http://www.w3.org/2000/svg" style="width:16px; height:16px;" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M12 4v16m8-8H4"/></svg>
                                    </button>
                                </div>

                                <button @click="picker.submit()" :disabled="picker.adding" type="button"
                                    style="flex:1; display:flex; align-items:center; justify-content:center; gap:8px; padding:10px 24px; background:#10b981; color:white; font-weight:700; border-radius:12px; box-shadow:0 4px 12px rgba(16,185,129,0.25); cursor:pointer; border:none; font-size:14px; transition:all 0.2s;">
                                    <template x-if="!picker.adding && !picker.added">
                                        <span style="display:flex; align-items:center; gap:8px;">
                                            <svg xmlns="http://www.w3.org/2000/svg" style="width:16px; height:16px;" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 100 4 2 2 0 000-4z"/></svg>
                                            <?php echo e(__('messages.add_to_cart')); ?>

                                        </span>
                                    </template>
                                    <template x-if="picker.adding">
                                        <span><?php echo e(__('messages.adding')); ?></span>
                                    </template>
                                    <template x-if="picker.added">
                                        <span style="display:flex; align-items:center; gap:8px;">
                                            <svg xmlns="http://www.w3.org/2000/svg" style="width:16px; height:16px;" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/></svg>
                                            <?php echo e(__('messages.added')); ?>

                                        </span>
                                    </template>
                                </button>
                            </div>

                            <template x-if="picker.message">
                                <p style="margin-top:8px; font-size:12px; font-weight:500;" :class="picker.success ? 'text-green-600' : 'text-red-600'" x-text="picker.message"></p>
                            </template>
                        </div>
                    </template>

                    
                    <template x-if="!picker.selected || picker.selected.stock < 1">
                        <div style="margin-top:20px;">
                            <button disabled type="button" style="width:100%; display:flex; align-items:center; justify-content:center; gap:8px; padding:14px 24px; background:#e5e7eb; color:#6b7280; font-weight:700; border-radius:12px; cursor:not-allowed; font-size:14px; border:none;">
                                <?php echo e(__('messages.out_of_stock')); ?>

                            </button>
                        </div>
                    </template>

                    <a :href="'/shop/' + (picker.selected ? picker.selected.slug : product.slug)" style="margin-top:16px; display:block; text-align:center; font-size:12px; color:#059669; font-weight:500; padding:8px 0; border-top:1px solid #f3f4f6; text-decoration:none;"><?php echo e(__('messages.view_full_details')); ?></a>
                </div>
            </div>
        </template>
    </div>
</div>
<?php /**PATH C:\Users\Smk\Desktop\supermarket\resources\views/components/product-quick-view.blade.php ENDPATH**/ ?>