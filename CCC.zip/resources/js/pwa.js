import './bootstrap';

var swRegistration = null;
var isSubscribed = false;

var BASE_URL = window.__APP_URL || '';

document.addEventListener('DOMContentLoaded', function () {
    if ('serviceWorker' in navigator && 'PushManager' in window) {
        registerServiceWorker();
    }
});

function registerServiceWorker() {
    navigator.serviceWorker
        .register(BASE_URL + '/sw.js')
        .then(function (registration) {
            swRegistration = registration;
            registration.addEventListener('updatefound', function () {
                if (registration.installing) {
                    registration.installing.addEventListener('statechange', function () {
                        if (this.state === 'activated') {
                            window.dispatchEvent(new CustomEvent('sw-ready', { detail: { registration: registration } }));
                        }
                    });
                }
            });
            window.dispatchEvent(new CustomEvent('sw-ready', { detail: { registration: registration } }));
        })
        .catch(function (error) {
            console.warn('Service worker registration failed:', error);
        });
}

function urlBase64ToUint8Array(base64String) {
    var padding = '='.repeat((4 - (base64String.length % 4)) % 4);
    var base64 = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/');
    var rawData = window.atob(base64);
    var output = new Uint8Array(rawData.length);
    for (var i = 0; i < rawData.length; ++i) {
        output[i] = rawData.charCodeAt(i);
    }
    return output;
}

window.subscribeToPush = function () {
    if (!swRegistration) {
        return Promise.reject(new Error('Service worker not registered'));
    }

    return swRegistration.pushManager
        .subscribe({
            userVisibleOnly: true,
            applicationServerKey: urlBase64ToUint8Array(window.VAPID_PUBLIC_KEY),
        })
        .then(function (subscription) {
            var subData = subscription.toJSON();
            return fetch(BASE_URL + '/push/subscribe', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json',
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content,
                },
                body: JSON.stringify({
                    endpoint: subData.endpoint,
                    auth_key: subData.keys.auth,
                    p256dh_key: subData.keys.p256dh,
                }),
            });
        })
        .then(function (response) {
            if (response.ok) {
                isSubscribed = true;
                window.dispatchEvent(new CustomEvent('push-subscription-changed', { detail: { subscribed: true } }));
            }
            return response.json();
        });
};

window.unsubscribeFromPush = function () {
    if (!swRegistration) {
        return Promise.reject(new Error('Service worker not registered'));
    }

    return swRegistration.pushManager
        .getSubscription()
        .then(function (subscription) {
            if (!subscription) {
                isSubscribed = false;
                window.dispatchEvent(new CustomEvent('push-subscription-changed', { detail: { subscribed: false } }));
                return { success: true };
            }
            return subscription.unsubscribe().then(function () {
                return fetch(BASE_URL + '/push/unsubscribe', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json',
                        'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content,
                    },
                    body: JSON.stringify({
                        endpoint: subscription.toJSON().endpoint,
                    }),
                });
            });
        })
        .then(function (response) {
            if (response && response.ok) {
                isSubscribed = false;
                window.dispatchEvent(new CustomEvent('push-subscription-changed', { detail: { subscribed: false } }));
            }
            return response ? response.json() : { success: true };
        });
};

window.getPushSubscriptionStatus = function () {
    if (!swRegistration) {
        return Promise.resolve(false);
    }
    return swRegistration.pushManager.getSubscription().then(function (subscription) {
        isSubscribed = !!subscription;
        return isSubscribed;
    });
};
