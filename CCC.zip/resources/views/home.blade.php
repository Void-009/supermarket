@extends('layouts.main')

@section('content')

{{-- ============================================ --}}
{{-- HERO SECTION                                --}}
{{-- ============================================ --}}
<section id="hero-section" @if($slideshowImages->count()) x-data="heroSlideshow({{ $slideshowImages->count() }})" @endif class="relative overflow-hidden bg-gradient-to-br from-emerald-50 via-emerald-50 to-emerald-100">

    @if($slideshowImages->count())
        {{-- Slideshow Backgrounds --}}
        @foreach($slideshowImages as $idx => $slide)
            <div :style="'opacity: ' + (current === {{ $idx }} ? '1' : '0')"
                 style="opacity: {{ $idx === 0 ? '1' : '0' }}"
                 class="absolute inset-0 transition-opacity duration-700 ease-in-out"
                 aria-hidden="{{ $idx === 0 ? 'false' : 'true' }}">
                <img src="{{ Storage::disk('public')->url($slide->path) }}" alt="M-DELIGHT SINGER STORES"
                     class="w-full h-full object-cover" loading="{{ $idx === 0 ? 'eager' : 'lazy' }}">
            </div>
        @endforeach
        <div class="absolute inset-0 bg-gradient-to-br from-emerald-900/80 via-emerald-900/60 to-gray-900/70"></div>

        {{-- Slideshow Dots --}}
        <div class="absolute bottom-6 left-1/2 -translate-x-1/2 flex items-center gap-2 z-20">
            @foreach($slideshowImages as $idx => $slide)
                <button @click="current = {{ $idx }}; restart()" :class="current === {{ $idx }} ? 'w-8 bg-white' : 'w-3 bg-white/50'" class="h-2 rounded-full transition-all duration-300" :aria-label="'Go to slide {{ $idx + 1 }}'"></button>
            @endforeach
        </div>
    @endif

    <div class="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 lg:py-14">
        <div class="max-w-3xl mx-auto text-center">
            <div class="inline-flex items-center gap-2 {{ $slideshowImages->count() ? 'bg-white/90 text-emerald-700' : 'bg-emerald-100 text-emerald-700' }} px-3 py-1 rounded-full text-xs sm:text-sm font-semibold mb-3">
                <i data-lucide="sparkles" class="w-3.5 h-3.5"></i>
                {{ __('messages.your_trusted') }}
            </div>

            <h1 class="text-2xl sm:text-4xl lg:text-5xl font-extrabold {{ $slideshowImages->count() ? 'text-white' : 'text-gray-900' }} leading-tight tracking-tight">
                {{ __('messages.hero_title_1') }}<br>
                <span class="{{ $slideshowImages->count() ? 'text-emerald-300' : 'text-emerald-600' }}">{{ __('messages.hero_title_2') }}</span> {{ __('messages.hero_title_3') }}
            </h1>

            <p class="mt-3 text-sm sm:text-base {{ $slideshowImages->count() ? 'text-emerald-50' : 'text-gray-600' }} max-w-2xl mx-auto leading-relaxed">
                {{ __('messages.hero_desc') }}
            </p>

            <div class="mt-5 flex flex-col sm:flex-row items-center justify-center gap-3">
                <a href="{{ route('shop.index') }}" class="inline-flex items-center gap-2 px-6 py-2.5 bg-emerald-500 hover:bg-emerald-600 text-white font-semibold rounded-xl shadow-lg shadow-emerald-500/25 hover:shadow-emerald-500/40 transition-all duration-300">
                    <i data-lucide="shopping-bag" class="w-4 h-4"></i>
                    {{ __('messages.shop_now') }}
                </a>
                <a href="https://wa.me/{{ $activePaymentSettings->whatsapp_number ?? '2348000000000' }}" target="_blank" rel="noopener noreferrer" class="inline-flex items-center gap-2 px-5 py-2.5 {{ $slideshowImages->count() ? 'bg-white/90 hover:bg-white text-gray-800 border-white/20' : 'bg-white hover:bg-gray-50 text-gray-700 border-gray-200' }} font-semibold rounded-xl border transition-all duration-300">
                    <i data-lucide="message-circle" class="w-4 h-4"></i>
                    {{ __('messages.order_via_whatsapp') }}
                </a>
            </div>

            {{-- Trust row: happy customers paired with same-day delivery --}}
            <div class="mt-5 flex flex-wrap items-center justify-center gap-x-8 gap-y-3 text-sm {{ $slideshowImages->count() ? 'text-emerald-50' : 'text-gray-500' }}">
                <div class="flex items-center gap-2">
                    <div class="flex -space-x-1">
                        <div class="w-6 h-6 rounded-full bg-emerald-400 border-2 border-white flex items-center justify-center text-[10px] text-white font-bold">M</div>
                        <div class="w-6 h-6 rounded-full bg-sky-400 border-2 border-white flex items-center justify-center text-[10px] text-white font-bold">A</div>
                        <div class="w-6 h-6 rounded-full bg-amber-400 border-2 border-white flex items-center justify-center text-[10px] text-white font-bold">T</div>
                        <div class="w-6 h-6 rounded-full bg-emerald-600 border-2 border-white flex items-center justify-center text-[10px] text-white font-bold">+</div>
                    </div>
                    <span>{{ __('messages.happy_customers') }}</span>
                </div>
                <span class="hidden sm:block w-px h-6 bg-current opacity-30"></span>
                <div class="flex items-center gap-2">
                    <i data-lucide="truck" class="w-4 h-4 text-emerald-400"></i>
                    <span>{{ __('messages.same_day_delivery') }}</span>
                </div>
            </div>
        </div>
    </div>
</section>


{{-- ============================================ --}}
{{-- RAIL 1: TOP DEALS TODAY                      --}}
{{-- ============================================ --}}
@if($deals->count())
    <x-product-rail
        :title="__('messages.top_deals')"
        :items="$deals"
        :href="route('shop.index')"
    />
@endif


{{-- ============================================ --}}
{{-- CATEGORY SLIDE MARQUEE                       --}}
{{-- ============================================ --}}
@if($categories->count())
<section class="py-10 lg:py-12 bg-gray-50 overflow-hidden">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-6 flex flex-wrap items-end justify-between gap-x-4 gap-y-2">
        <div>
            <span class="inline-block text-emerald-600 font-semibold text-sm uppercase tracking-widest mb-1">{{ __('messages.browse') }}</span>
            <h2 class="text-xl sm:text-2xl lg:text-3xl font-bold text-gray-900" style="font-family:'Poppins',sans-serif;">{{ __('messages.shop_by_category') }}</h2>
        </div>
        <a href="{{ route('shop.index') }}" class="inline-flex items-center gap-2 text-sm font-semibold text-emerald-600 hover:text-emerald-700 transition-colors shrink-0">
            {{ __('messages.view_all_products') }}
            <i data-lucide="arrow-right" class="w-4 h-4"></i>
        </a>
    </div>

    <div class="marquee">
        <div class="marquee-track">
            <div class="marquee-set">
                @foreach($categories as $idx => $category)
                    <x-category-slide :category="$category" :index="$idx" />
                @endforeach
            </div>
            <div class="marquee-set" aria-hidden="true">
                @foreach($categories as $idx => $category)
                    <x-category-slide :category="$category" :index="$idx" />
                @endforeach
            </div>
        </div>
    </div>
</section>
@endif


{{-- ============================================ --}}
{{-- RAIL 2: NEW ARRIVALS                         --}}
{{-- ============================================ --}}
@if($recentItems->count())
    <x-product-rail
        :title="__('messages.new_arrivals')"
        :items="$recentItems"
        :href="route('shop.index')"
    />
@endif

@endsection

@push('scripts')
<script>
function heroSlideshow(total) {
    return {
        current: 0,
        total: total,
        timer: null,
        init() {
            this.restart();
        },
        restart() {
            if (this.timer) clearInterval(this.timer);
            if (this.total > 1) {
                this.timer = setInterval(() => {
                    this.current = (this.current + 1) % this.total;
                }, 5000);
            }
        },
    };
}
</script>
@endpush
