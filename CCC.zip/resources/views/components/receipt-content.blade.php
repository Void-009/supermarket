@props(['order'])

<div class="receipt-pop">
    <div class="rc-center">
        <div class="rc-store">M-DELIGHT SINGER STORES</div>
        <div class="rc-sub">RECEIPT &bull; ORDER RECEIPT</div>
    </div>
    <div class="rc-hr4"></div>

    <div class="rc-order-num">#{{ $order->id }}</div>
    <div class="rc-hr2"></div>

    <table class="rc-info">
        <tr><td class="rc-l">Date:</td><td class="rc-v">{{ $order->created_at->format('d/m/Y') }}</td></tr>
        <tr><td class="rc-l">Time:</td><td class="rc-v">{{ $order->created_at->format('g:i A') }}</td></tr>
        <tr><td class="rc-l">Customer:</td><td class="rc-v">{{ $order->customer_name }}</td></tr>
        <tr><td class="rc-l">Phone:</td><td class="rc-v">{{ $order->customer_phone }}</td></tr>
        @if($order->customer_email)
        <tr><td class="rc-l">Email:</td><td class="rc-v">{{ $order->customer_email }}</td></tr>
        @endif
        <tr><td class="rc-l">Payment:</td><td class="rc-v">{{ str_replace('_', ' ', ucfirst($order->payment_method)) }}</td></tr>
        <tr><td class="rc-l">Ref No:</td><td class="rc-v">{{ $order->payment_reference }}</td></tr>
        @if($order->delivery_method === 'delivery' && $order->delivery_address)
        <tr><td class="rc-l">Address:</td><td class="rc-v">{{ $order->delivery_address }}</td></tr>
        @endif
    </table>

    <div class="rc-hr2"></div>

    <table class="rc-items">
        <thead>
            <tr>
                <th style="width:54%;">ITEM</th>
                <th class="rc-th-qty" style="width:12%;">QTY</th>
                <th class="rc-th-total" style="width:34%;">TOTAL</th>
            </tr>
        </thead>
        <tbody>
            @foreach($order->items as $item)
            <tr class="rc-item">
                <td class="rc-in">{{ $item->item->name ?? 'Deleted Item' }}<br><span class="rc-price">₦{{ number_format($item->price_at_order, 0) }}</span></td>
                <td class="rc-iq">{{ $item->quantity }}</td>
                <td class="rc-it">₦{{ number_format($item->price_at_order * $item->quantity, 0) }}</td>
            </tr>
            @endforeach
        </tbody>
    </table>

    <div class="rc-hr2"></div>

    <table class="rc-totals">
        <tr>
            <td class="rc-l">Subtotal</td>
            <td class="rc-v">₦{{ number_format($order->total_amount - $order->delivery_fee, 0) }}</td>
        </tr>
        @if($order->delivery_fee > 0)
        <tr>
            <td class="rc-l">Delivery Fee</td>
            <td class="rc-v">₦{{ number_format($order->delivery_fee, 0) }}</td>
        </tr>
        @endif
    </table>

    <div class="rc-hr4"></div>

    <table class="rc-totals rc-grand">
        <tr>
            <td class="rc-l">TOTAL</td>
            <td class="rc-v">₦{{ number_format($order->total_amount, 0) }}</td>
        </tr>
    </table>

    <div class="rc-hr2"></div>

    <div class="rc-center rc-paynote">
        @if($order->payment_method === 'cash_on_delivery')
            ** UNPAID - CASH ON DELIVERY **
        @else
            PAYMENT: {{ strtoupper($order->payment_status) }}
        @endif
    </div>

    <div class="rc-hr4"></div>

    <div class="rc-center rc-ftr">
        THANK YOU FOR YOUR PATRONAGE!<br>
        M-DELIGHT SINGER STORES
    </div>
</div>
