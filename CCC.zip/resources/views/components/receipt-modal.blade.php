<style id="receipt-style">
    .receipt-pop {
        font-family: 'Lucida Console', 'Courier New', monospace;
        font-size: 11px;
        width: 70mm;
        max-width: 100%;
        margin: 0 auto;
        padding: 3mm 4mm;
        color: #000;
        background: #fff;
        line-height: 1.5;
        font-weight: bold;
        box-shadow: 0 1px 3px rgba(0, 0, 0, 0.08);
    }
    .receipt-pop .rc-center { text-align: center; }
    .receipt-pop .rc-store { font-size: 16px; letter-spacing: 2px; font-weight: bold; text-align: center; }
    .receipt-pop .rc-sub { font-size: 10px; text-align: center; font-weight: bold; }
    .receipt-pop .rc-hr4 { border: none; border-top: 4px solid #000; margin: 4px 0; }
    .receipt-pop .rc-hr2 { border: none; border-top: 2px solid #000; margin: 3px 0; }
    .receipt-pop .rc-order-num { font-size: 18px; text-align: center; letter-spacing: 1px; font-weight: bold; }
    .receipt-pop .rc-info { width: 100%; font-size: 11px; font-weight: bold; }
    .receipt-pop .rc-info td { padding: 1px 0; white-space: nowrap; }
    .receipt-pop .rc-l { text-align: left; width: 30%; }
    .receipt-pop .rc-v { text-align: right; width: 70%; word-break: break-all; white-space: normal; }
    .receipt-pop .rc-items { width: 100%; font-size: 11px; font-weight: bold; }
    .receipt-pop .rc-items th { text-align: left; padding: 2px 0; font-size: 11px; border-bottom: 2px solid #000; }
    .receipt-pop .rc-items th.rc-th-qty { text-align: center; }
    .receipt-pop .rc-items th.rc-th-total { text-align: right; }
    .receipt-pop .rc-items td { padding: 2px 0; vertical-align: top; }
    .receipt-pop .rc-item td { padding-bottom: 6px; border-bottom: 1.5px dashed #000; }
    .receipt-pop .rc-item:last-child td { border-bottom: none; }
    .receipt-pop .rc-in { text-align: left; word-break: break-all; }
    .receipt-pop .rc-iq { text-align: center; }
    .receipt-pop .rc-it { text-align: right; white-space: nowrap; }
    .receipt-pop .rc-price { font-size: 9px; }
    .receipt-pop .rc-totals { width: 100%; font-size: 11px; font-weight: bold; }
    .receipt-pop .rc-totals td { padding: 2px 0; }
    .receipt-pop .rc-grand td { padding: 4px 0; font-size: 15px; }
    .receipt-pop .rc-paynote { font-size: 11px; }
    .receipt-pop .rc-ftr { font-size: 10px; margin-top: 6px; }
</style>

<div x-data="receiptModal()" x-init="init()">
    <div x-show="show" x-cloak @keydown.escape.window="close()" class="fixed inset-0 z-[80] flex items-center justify-center p-4" style="display:none;">
        <div class="absolute inset-0 bg-black/60" @click="close()"></div>
            <div x-show="show" x-transition:enter="transition ease-out duration-200" x-transition:enter-start="opacity-0 scale-95" x-transition:enter-end="opacity-100 scale-100" x-transition:leave="transition ease-in duration-150" x-transition:leave-start="opacity-100 scale-100" x-transition:leave-end="opacity-0 scale-95"
                class="relative bg-white rounded-2xl shadow-2xl w-full max-w-md max-h-[92vh] flex flex-col overflow-hidden">
                <div class="flex items-center justify-between px-5 py-3 border-b border-gray-100 shrink-0 bg-gray-50">
                    <h3 class="font-bold text-gray-900" style="font-family:'Poppins',sans-serif;">{{ __('messages.receipt') }} — #<span x-text="orderId"></span></h3>
                    <button @click="close()" class="p-1.5 text-gray-400 hover:text-gray-600 hover:bg-gray-200 rounded-lg transition-colors" aria-label="Close">
                        <i data-lucide="x" class="w-5 h-5"></i>
                    </button>
                </div>
                <div class="flex-1 min-h-0 overflow-y-auto bg-gray-100 p-4" x-html="html"></div>
            <div class="flex items-center gap-3 px-5 py-3 border-t border-gray-100 shrink-0 bg-gray-50">
                <button @click="print()" class="flex-1 inline-flex items-center justify-center gap-2 px-4 py-2.5 text-sm font-semibold text-white bg-emerald-500 hover:bg-emerald-600 rounded-xl transition-colors">
                    <i data-lucide="printer" class="w-4 h-4"></i> {{ __('messages.print') }}
                </button>
                <button @click="close()" class="flex-1 inline-flex items-center justify-center gap-2 px-4 py-2.5 text-sm font-medium text-gray-700 bg-white border border-gray-200 hover:bg-gray-50 rounded-xl transition-colors">
                    {{ __('messages.close') }}
                </button>
            </div>
        </div>
    </div>
</div>

<script>
    function openOrderReceipt(orderId) {
        window.dispatchEvent(new CustomEvent('open-receipt', { detail: { id: orderId } }));
    }

    function receiptModal() {
        return {
            show: false,
            orderId: null,
            html: '',

            init() {
                window.addEventListener('open-receipt', (e) => {
                    const id = e.detail.id;
                    const el = document.getElementById('receipt-' + id);
                    if (!el) return;
                    this.orderId = id;
                    this.html = el.innerHTML;
                    this.show = true;
                    document.body.style.overflow = 'hidden';
                    this.$nextTick(() => { if (window.lucide) lucide.createIcons(); });
                });
            },

            close() {
                this.show = false;
                document.body.style.overflow = '';
            },

            print() {
                if (!this.html || !this.orderId) return;
                const styles = document.getElementById('receipt-style');
                const css = styles ? styles.textContent : '';
                const win = window.open('', '_blank', 'width=400,height=650');
                if (!win) return;
                win.document.write(
                    '<!DOCTYPE html><html><head><meta charset="utf-8"><title>Receipt #' + this.orderId + '</title>' +
                    '<style>' + css + '</style></head><body>' + this.html + '</body></html>'
                );
                win.document.close();
                win.focus();
                setTimeout(() => { win.print(); }, 300);
            },
        };
    }
</script>
