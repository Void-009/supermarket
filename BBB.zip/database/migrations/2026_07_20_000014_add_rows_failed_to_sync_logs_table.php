<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // Duplicate of 000013: guarded so it is a no-op when the column exists.
        if (! Schema::hasColumn('sync_logs', 'rows_failed')) {
            Schema::table('sync_logs', function (Blueprint $table) {
                $table->integer('rows_failed')->default(0)->after('rows_created');
            });
        }
    }

    public function down(): void
    {
        Schema::table('sync_logs', function (Blueprint $table) {
            $table->dropColumn('rows_failed');
        });
    }
};
