<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Database\Eloquent\SoftDeletes;

class Order extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        "user_id", "customer_name", "customer_phone", "customer_email",
        "delivery_method", "delivery_address", "delivery_location_id", "payment_method", "delivery_fee",
        "is_bulk_order", "delivery_fee_status",
        "status", "total_amount", "payment_status", "payment_reference", "bank_receipt_path",
        "notes", "processed_by",
    ];

    protected function casts(): array
    {
        return [
            "total_amount" => "decimal:2",
            "delivery_fee" => "decimal:2",
            "is_bulk_order" => "boolean",
        ];
    }

    public function scopeNew(Builder $query): Builder
    {
        return $query->where("status", "new");
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function processor(): BelongsTo
    {
        return $this->belongsTo(User::class, 'processed_by');
    }

    public function items(): HasMany
    {
        return $this->hasMany(OrderItem::class);
    }

    public function payment(): HasOne
    {
        return $this->hasOne(Payment::class);
    }

    public function deliveryLocation(): BelongsTo
    {
        return $this->belongsTo(DeliveryLocation::class);
    }

    public function complaints(): HasMany
    {
        return $this->hasMany(OrderComplaint::class);
    }
}