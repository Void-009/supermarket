<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Storage;

class Category extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        "name", "slug", "description", "image",
        "is_active", "sort_order", "parent_id",
    ];

    protected function casts(): array
    {
        return [
            "is_active" => "boolean",
            "sort_order" => "integer",
        ];
    }

    protected static function boot(): void
    {
        parent::boot();
        static::creating(function (Category $category) {
            if (empty($category->slug)) {
                $category->slug = Str::slug($category->name);
            }
        });
        static::updating(function (Category $category) {
            if ($category->isDirty("name") && empty($category->slug)) {
                $category->slug = Str::slug($category->name);
            }
        });
    }

    public function parent(): BelongsTo
    {
        return $this->belongsTo(Category::class, "parent_id");
    }

    public function children(): HasMany
    {
        return $this->hasMany(Category::class, "parent_id");
    }

    public function items(): HasMany
    {
        return $this->hasMany(Item::class);
    }

    public function images(): HasMany
    {
        return $this->hasMany(CategoryImage::class)->orderBy('sort_order')->orderBy('id');
    }

    /**
     * Title-cased, consistently-spaced display name.
     * Fixes inconsistent casing ("padlock") and ampersand spacing ("BAGS &SACKS").
     */
    public function getTitleNameAttribute(): string
    {
        $normalized = preg_replace('/\s*&\s*/', ' & ', (string) $this->name);

        return Str::title($normalized);
    }

    /**
     * The representative image for the category (primary uploaded image,
     * otherwise the first uploaded image, otherwise the legacy image field).
     */
    public function displayImage(): ?string
    {
        if ($this->relationLoaded('images') === false) {
            $this->load('images');
        }

        $primary = $this->images->firstWhere('is_primary', true);
        $first = $this->images->first();

        $path = $primary?->path ?? $first?->path ?? $this->image;

        return $path ? asset('storage/' . $path) : null;
    }
}
