<?php

namespace App\Http\Controllers\Customer;

use App\Http\Controllers\Controller;
use App\Models\Order;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class OrderController extends Controller
{
    public function index()
    {
        $orders = Order::with(['items.item', 'deliveryLocation'])
            ->where('user_id', Auth::id())
            ->latest()
            ->paginate(15);

        return view('customer.orders.index', compact('orders'));
    }

    public function show(Order $order)
    {
        if ($order->user_id !== Auth::id()) {
            abort(403, 'This is not your order.');
        }

        $order->load(['items.item', 'payment', 'deliveryLocation', 'complaints']);

        $statusSteps = ['new', 'processing', 'paid', 'shipped', 'delivered'];
        $currentIndex = array_search($order->status, $statusSteps);
        $isCancelled = $order->status === 'cancelled';

        return view('customer.orders.show', compact('order', 'statusSteps', 'currentIndex', 'isCancelled'));
    }
}
