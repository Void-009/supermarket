<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Item;
use App\Models\ItemBarcode;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class SearchController extends Controller
{
    public function search(Request $request): JsonResponse
    {
        $query = trim($request->input('q', ''));

        if (strlen($query) < 1) {
            return response()->json(['items' => []]);
        }

        // 1. Exact barcode match (highest priority — for scanner)
        $barcodeMatch = ItemBarcode::where('barcode_value', $query)
            ->whereHas('item', fn ($q) => $q->where('is_visible_online', true))
            ->with('item.category')
            ->first();

        if ($barcodeMatch && $barcodeMatch->item) {
            return response()->json(['items' => [$this->formatItem($barcodeMatch->item)], 'exact_match' => true]);
        }

        // 2. Exact ID match (numeric query = item ID)
        if (ctype_digit($query)) {
            $idMatch = Item::visible()
                ->with('category')
                ->where(function ($q) use ($query) {
                    $q->where('id', $query)
                      ->orWhere('pos_item_id', $query);
                })
                ->first();

            if ($idMatch) {
                return response()->json(['items' => [$this->formatItem($idMatch)], 'exact_match' => true]);
            }
        }

        // 3. Search — optimized query with join, selected columns, no limit
        $items = DB::table('items')
            ->leftJoin('categories', 'items.category_id', '=', 'categories.id')
            ->where('items.is_visible_online', true)
            ->where(function ($q) use ($query) {
                $q->where('items.name', 'like', "%{$query}%")
                  ->orWhere('items.display_name', 'like', "%{$query}%")
                  ->orWhereIn('items.id', function ($bq) use ($query) {
                      $bq->select('item_id')
                         ->from('item_barcodes')
                         ->where('barcode_value', 'like', "%{$query}%");
                  });
            })
            ->select(
                'items.id',
                'items.name',
                'items.display_name',
                'items.slug',
                'items.pos_item_id',
                'items.parent_item_number',
                'items.selling_price',
                'items.discount_percentage',
                'items.discount_is_active',
                'items.discount_starts_at',
                'items.discount_ends_at',
                'items.image_url',
                'items.quantity',
                'items.stock_status',
                'categories.name as category_name'
            )
            ->when($request->filled('category'), function ($q) use ($request) {
                $q->orderByRaw('CASE WHEN categories.slug = ? THEN 0 ELSE 1 END', [$request->category]);
            })
            ->orderBy('items.name')
            ->get();

        $posIds = $items->pluck('pos_item_id')->filter()->values();
        $parentNumbers = $items->pluck('parent_item_number')->filter()->values();
        $variationsByParent = Item::whereIn('parent_item_number', $posIds)
            ->orderBy('display_name')
            ->get()
            ->groupBy('parent_item_number');
        $parentsById = Item::whereIn('pos_item_id', $parentNumbers)
            ->get()
            ->keyBy('pos_item_id');

        $results = $items->map(function ($item) use ($variationsByParent, $parentsById) {
            $isVariation = ! empty($item->parent_item_number);

            $variations = collect();
            $parent = null;
            if ($isVariation) {
                $variations = $variationsByParent->get($item->parent_item_number, collect());
                $parent = $parentsById->get($item->parent_item_number);
            } else {
                $variations = $variationsByParent->get($item->pos_item_id, collect());
            }

            $options = $variations->map(fn ($v) => $this->variationOption($v))->values();
            if ($parent && $isVariation && $options->doesntContain('id', $parent->id)) {
                $options->prepend($this->parentOption($parent));
            }
            $stock = $parent && $isVariation ? (int) $parent->quantity : (int) $item->quantity;

            return [
                'id' => $item->id,
                'name' => $item->name,
                'display_name' => $item->display_name,
                'slug' => $item->slug,
                'selling_price' => (float) $item->selling_price,
                'discount_price' => $this->effectivePrice($item),
                'image_url' => $item->image_url ?: ($parent?->image_url ?? null),
                'stock' => $stock,
                'stock_status' => $item->stock_status,
                'quantity' => $stock,
                'category' => $item->category_name,
                'is_variation' => $isVariation,
                'parent' => $parent ? [
                    'id' => $parent->id,
                    'name' => $parent->name,
                    'display_name' => $parent->display_name,
                    'slug' => $parent->slug,
                ] : null,
                'variations' => $options->all(),
            ];
        });

        return response()->json(['items' => $results, 'exact_match' => false]);
    }

    private function formatItem(Item $item): array
    {
        $variations = collect();
        $parent = null;

        if ($item->isVariation() && $item->parent_item_number) {
            $parent = Item::where('pos_item_id', $item->parent_item_number)->first();
            $variations = Item::where('parent_item_number', $item->parent_item_number)
                ->orderBy('display_name')
                ->get();
            if ($variations->doesntContain('id', $item->id)) {
                $variations->prepend($item);
            }
            if ($parent && $variations->doesntContain('id', $parent->id)) {
                $variations->prepend($parent);
            }
        } else {
            $variations = Item::where('parent_item_number', $item->pos_item_id)
                ->orderBy('display_name')
                ->get();
        }

        return [
            'id' => $item->id,
            'name' => $item->name,
            'display_name' => $item->display_name,
            'slug' => $item->slug,
            'selling_price' => (float) $item->selling_price,
            'discount_price' => $item->isDiscounted() ? (float) $item->discount_price : null,
            'image_url' => $item->image_url,
            'stock' => $item->effectiveQuantity(),
            'stock_status' => $item->stock_status,
            'quantity' => $item->effectiveQuantity(),
            'category' => $item->category?->name,
            'is_variation' => $item->isVariation(),
            'parent' => $parent ? [
                'id' => $parent->id,
                'name' => $parent->name,
                'display_name' => $parent->display_name,
                'slug' => $parent->slug,
            ] : null,
            'variations' => $variations->map(fn ($v) => $v->isVariation()
                ? $this->variationOption($v)
                : $this->parentOption($v))->values()->all(),
        ];
    }

    private function variationOption(Item $item): array
    {
        return [
            'id' => $item->id,
            'name' => $item->name,
            'display_name' => $item->display_name,
            'slug' => $item->slug,
            'selling_price' => (float) $item->effectivePrice(),
            'compare_at_price' => $item->isDiscounted() ? (float) $item->selling_price : null,
            'stock' => (int) $item->effectiveQuantity(),
            'is_variation' => true,
        ];
    }

    private function parentOption(Item $item): array
    {
        return [
            'id' => $item->id,
            'name' => $item->name,
            'display_name' => $item->display_name,
            'slug' => $item->slug,
            'selling_price' => (float) $item->effectivePrice(),
            'compare_at_price' => $item->isDiscounted() ? (float) $item->selling_price : null,
            'stock' => (int) $item->effectiveQuantity(),
            'is_variation' => false,
        ];
    }

    private function effectivePrice(object $item): ?float
    {
        $now = now();
        $active = (bool) $item->discount_is_active;

        if ($item->discount_starts_at && $now < $item->discount_starts_at) {
            $active = false;
        }
        if ($item->discount_ends_at && $now > $item->discount_ends_at) {
            $active = false;
        }

        if (!$active || empty($item->discount_percentage)) {
            return null;
        }

        return round((float) $item->selling_price * (1 - (float) $item->discount_percentage / 100), 2);
    }
}
