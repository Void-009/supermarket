<?php

namespace App\Http\Controllers;

use App\Models\Item;
use App\Models\ItemBarcode;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class PriceCheckerController extends Controller
{
    public function index(): View
    {
        return view('price-checker.index');
    }

    public function search(Request $request): JsonResponse
    {
        $request->validate(['q' => 'required|string|max:100']);
        $query = trim($request->input('q'));

        if ($query === '') {
            return response()->json(['items' => [], 'exact_match' => false]);
        }

        $queryLower = mb_strtolower($query);
        $items = collect();
        $exactMatch = false;

        // 1. Try exact barcode match (highest priority)
        $barcode = ItemBarcode::where('barcode_value', $queryLower)
            ->with('item.category')
            ->first();

        if ($barcode?->item?->is_visible_online) {
            $exactMatch = true;
            $items = collect([$barcode->item]);
        }

        // 2. Try last-4-digits barcode match
        if ($items->isEmpty() && strlen($query) >= 2) {
            $suffixBarcodes = ItemBarcode::where('barcode_value', 'like', '%' . $queryLower)
                ->with('item.category')
                ->get()
                ->pluck('item')
                ->filter(fn($i) => $i && $i->is_visible_online)
                ->unique('id');

            if ($suffixBarcodes->isNotEmpty()) {
                $items = $suffixBarcodes->values();
            }
        }

        // 3. Try partial barcode match
        if ($items->isEmpty()) {
            $partialBarcodes = ItemBarcode::where('barcode_value', 'like', '%' . $queryLower . '%')
                ->with('item.category')
                ->get()
                ->pluck('item')
                ->filter(fn($i) => $i && $i->is_visible_online)
                ->unique('id');

            if ($partialBarcodes->isNotEmpty()) {
                $items = $partialBarcodes->values();
            }
        }

        // 4. Try exact item ID or pos_item_id
        if ($items->isEmpty() && ctype_digit($query)) {
            $idItem = Item::visible()
                ->where(function ($q) use ($query) {
                    $q->where('id', $query)
                      ->orWhere('pos_item_id', $query);
                })
                ->first();
            if ($idItem) {
                $exactMatch = true;
                $items = collect([$idItem]);
            }
        }

        // 5. Try name / display name partial match
        if ($items->isEmpty()) {
            $nameItems = Item::visible()
                ->where(function ($q) use ($query) {
                    $q->where('name', 'like', '%' . $query . '%')
                      ->orWhere('display_name', 'like', '%' . $query . '%');
                })
                ->with('category')
                ->limit(20)
                ->get();

            if ($nameItems->isNotEmpty()) {
                $items = $nameItems;
            }
        }

        // 5b. Try category name match
        if ($items->isEmpty()) {
            $categoryItems = Item::visible()
                ->whereHas('category', function ($q) use ($query) {
                    $q->where('name', 'like', '%' . $query . '%');
                })
                ->with('category')
                ->limit(20)
                ->get();

            if ($categoryItems->isNotEmpty()) {
                $items = $categoryItems;
            }
        }

        // 6. Fallback to general search
        if ($items->isEmpty()) {
            $fallback = Item::visible()
                ->where(function ($q) use ($query) {
                    $q->where('name', 'like', '%' . $query . '%')
                      ->orWhere('display_name', 'like', '%' . $query . '%')
                      ->orWhereHas('barcodes', fn($q) => $q->where('barcode_value', 'like', '%' . $query . '%'));
                })
                ->with('category')
                ->limit(20)
                ->get();

            if ($fallback->isNotEmpty()) {
                $items = $fallback;
            }
        }

        $formatted = $items->map(function ($item) {
            $item->loadMissing('barcodes');
            $discountPrice = $item->isDiscounted() ? $item->discount_price : null;
            return [
                'id' => $item->id,
                'name' => $item->name,
                'display_name' => $item->display_name,
                'slug' => $item->slug,
                'selling_price' => (float) $item->selling_price,
                'discount_price' => $discountPrice ? (float) $discountPrice : null,
                'image_url' => $item->image_url,
                'stock' => $item->effectiveQuantity(),
                'stock_status' => $item->stock_status,
                'category' => $item->category?->name ?? '',
                'barcodes' => $item->barcodes->pluck('barcode_value'),
            ];
        });

        return response()->json([
            'items' => $formatted,
            'exact_match' => $exactMatch,
        ]);
    }
}
